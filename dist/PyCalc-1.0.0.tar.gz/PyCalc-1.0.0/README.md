# PyCalc
Just a simple desktop calculator app made with Python and QT
# Running the script:
- Install [Python](https://www.python.org/downloads)
- Install [PyQt5](https://pypi.org/project/PyQt5)
- Navigate to the repo directory, open your terminal/CMD and type `python calc.py`

**I tried with PyInstaller to make it executable but it did not work**
